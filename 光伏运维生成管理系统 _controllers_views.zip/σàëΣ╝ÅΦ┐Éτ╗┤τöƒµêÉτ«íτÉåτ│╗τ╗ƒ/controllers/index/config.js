var __root__ = '../..';
(function(){
    var tag = "script",attrs=[],src;
    attrs.push('type="text/javascript"');
    src=__root__+'/config.js';

    document.write('<',tag,' ',attrs.join(' '),'src=','"',src,'"','>','<','/',tag,'>');
})();
