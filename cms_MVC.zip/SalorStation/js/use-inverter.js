LAMJS.main(function(){
	'use strict';
	var System=this;
	var I=System.modules.exports.I || {};
	var init_tpl=false;
	var defaults={};

	/**
	 * function:获取逆变器数据
	 * @type {{getInverterData: Function}}
	 */
	I.ElectricalBox={
		'pop':{
			/**
			 *
			 * @param (dom)self 被点击的当前元素
			 * @param ()even 事件对象
			 * @param (String)pop 弹出层的id
			 * @param (String)html 插入的html结构
			 */
			'setPop':function(self,even,pop,html){
				var x,cx, y,left,top,$pop, W,overW;
//            console.log(e.currentTarget)
				//获取鼠标点击下的xy坐标

				$(self).append(html);

				//计算鼠标点击附近的位置
				//$pop = $(pop);
				//cx = self.offsetLeft;
				//x = even.offsetX - $pop[0].offsetLeft;
				//W = $("body").outerWidth();
				//left = W - $pop.width();
				//overW = cx > left ? cx-left +50 : 0;
				//$pop.css({
				//	'left':x-overW +'px'
				//});
				//

			},
			/**
			 * 汇流箱chart弹出层
			 */
			'get_pop_powerOut':function(){
				var tpl=[];
					tpl.push('<div class="_zh_powerOut sectionAutoCenter" id="pop_powerOut">');
					tpl.push('<span class="_zh_powerOut-close"></span>');
					tpl.push('<div id="echarts-column-chart"></div>');
					tpl.push('</div>');

				return tpl.join('');
			},
			/**
			 * 汇流箱表弹出层
			 */
			'get_pop_boxOut':function(D){
				var tpl=[];
				tpl.push('<table class="_zh_boxOut sectionAutoCenter" id="pop_boxOut">');
				tpl.push('<tr class="height36 tr-grey text-center">');
				tpl.push('<td rowspan="2" class="W90">汇流箱</td>');
				tpl.push('<td rowspan="2" class="W50">离散率(%)</td>');
				tpl.push('<td rowspan="2" class="W50">总电流(A)</td>');
				tpl.push('<td colspan="16">电流(A)');
				tpl.push('<span class="_zh_powerOut-close _zh_boxOut-close"></span>');
				tpl.push('</td>');
				tpl.push('</tr>');
				tpl.push('<tr class="tr-grey text-center">');
				tpl.push('<td>I1</td>');
				tpl.push('<td>I2</td>');
				tpl.push('<td>I3</td>');
				tpl.push('<td>I4</td>');
				tpl.push('<td>I5</td>');
				tpl.push('<td>I6</td>');
				tpl.push('<td>I7</td>');
				tpl.push('<td>I8</td>');
				tpl.push('<td>I9</td>');
				tpl.push('<td>I10</td>');
				tpl.push('<td>I11</td>');
				tpl.push('<td>I12</td>');
				tpl.push('<td>I13</td>');
				tpl.push('<td>I14</td>');
				tpl.push('<td>I15</td>');
				tpl.push('<td>I16</td>');
				tpl.push('</tr>');
				tpl.push('<tr class="text-center">');
				tpl.push('<td>汇流箱01</td>');
				tpl.push('<td>88.0%</td>');
				tpl.push('<td>88.0</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('<td>4.08</td>');
				tpl.push('</tr>');
				tpl.push('</table>');

				return tpl.join('');
			}

		},
		'getInverterData':function(init){
			defaults={
				'$view':$('#electricalBox'),
				'isAjax':true,
				'type': 'post',
				'url':  'js/dataJson-data.json',
				'data': {},
				'init_fun':function(v,D){
					var tpl=[];

					tpl.push('<li class="_zh_station col-sm-6 col-md-3" id="s_'+ v._id +'">');
					tpl.push('<div style="height:41px;">');
					tpl.push('<i class="_zh_station-stationicon"></i>');
					tpl.push('<div class="_zh_station-title">');
					tpl.push('<p class="MB5">电站1</p>');
					tpl.push('<span class="_zh_circleImg _zh_circleImg-green"></span>正常');
					tpl.push('</div>');
					tpl.push('</div>');
					tpl.push('<div class="_zh_station-c">');
					tpl.push('<div class="text1">');
					tpl.push('<p>输出功率</p>');
					tpl.push('<p>输入功率</p>');
					tpl.push('<p>单瓦发电量</p>');
					tpl.push('<p>日发电量</p>');
					tpl.push('</div>');
					tpl.push('<div class="data-value">');
					tpl.push('<p>42WhkW</p>');
					tpl.push('<p>88.88kW</p>');
					tpl.push('<p>42Wh</p>');
					tpl.push('<p>42WhkWh</p>');
					tpl.push('</div>');
					tpl.push('</div>');
					tpl.push('<div class="_zh_station-lineicon"></div>');
					tpl.push('</li>');

					return tpl.join('');
				},
				'getCurTpl':function(D){
					var tpl, i,len= D.data.length, v;

					for(i=0;i<len;i++){
						tpl=[];
						v= D.data[i];
						if(!System.empty( v['_id'])){
							tpl.push('<p>222</p>');
							tpl.push('<p>88.88kW</p>');
							tpl.push('<p>42Wh</p>');
							tpl.push('<p>42WhkWh</p>');

						}

						$('#s_'+v['_id']+' .data-value').html(tpl.join(''));

					}

				},
				'initTpl':function(D){
					var tpl=[], i,len= D.data.length, v;

					for(i=0;i<len;i++){
						v=D.data[i];
						if(!System.empty( v['id'])){
							if(System.isFunction(init.init_fun)){
								tpl.push(init.init_fun(v,D));

							}

						}
					}

					return tpl.join('');
				}
			};

			init = System.isObject(init) ? System.merge({},[init,defaults]) : defaults;

			var getTpl  = init.getCurTpl;
            var initTpl = init.initTpl;


			if(init.isAjax){
				System.Html.getFile(init.url || [__root__,'/js/dataJson-data.json'].join(''),function(D){
					if(init_tpl){//模版已初始化，刷新局部的某一部分
						getTpl(D);
					}else{//初始化模版，或重新刷新模版
						init_tpl =true;
						init.$view.html(initTpl(D));
					}
				},
				{
					type: init.type || 'post',
					data: init.data || {},
					dataType: 'json'

				});
				//$.ajax({
				//	type: init.type || 'post',
				//	url:  init.url  || 'js/dataJson-data.json',
				//	data: init.data || {},
				//	dataType: 'json',
				//	error:function(){
				//		throw new Error("Warning :没有取到数据！！！");
				//	},
				//	success: function(D){
				//		if(init_tpl){//模版已初始化，刷新局部的某一部分
				//			getTpl(D);
				//		}else{//初始化模版，或重新刷新模版
				//			init_tpl =true;
				//			init.$view.html(initTpl(D.data));
				//		}
                //
                //
				//	}
				//});
			}else{
				init_tpl =true;
				init.$view.html(initTpl(init.data.data));
			}



		}


	};

	I.ElectricalBox.init_tpl=function(b){
		init_tpl=b;
	};


	System.modules.exports.I=I;


});









