//加载当前项目通用文件

LAMJS.main(function(){
    'use strict';
    var System=this;
    System.root={
        'path':System.Config.Public.ROOT
    };
    System
        .import([
                    "/use",
                    "/bootstrap.min"
                    //"/skylo"
                ],System.root.path+'/js');
        //.import(["/flipclock/flipclock"],plugins);
});