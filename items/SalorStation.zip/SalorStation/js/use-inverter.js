LAMJS.main([LAMJS.Config.Public.ROOT],function(ROOT) {
	'use strict';
	var System=this;
	var I=System.modules.exports.I || {};
	var init_tpl=false;
	var defaults={};

	/**
	 * function:获取逆变器数据
	 * @type {{getInverterData: Function}}
	 */
	I.ElectricalBox={
		'pop':{
			/**
			 *
			 * @param (dom)self 被点击的当前元素
			 * @param ()even 事件对象
			 * @param (String)pop 弹出层的id
			 * @param (String)html 插入的html结构
			 */
			'setPop':function(self,even,pop,html){
				var x,cx, y,left,top,$pop, W,overW;
				var D ={};
//            console.log(e.currentTarget)
				//获取鼠标点击下的xy坐标
				if(1 === arguments.length && System.isObject(arguments[0])){
					D = arguments[0];
					$(D.self).append(D.html);
				}else{
					$(self).append(html);
				}



				//计算鼠标点击附近的位置
				//$pop = $(pop);
				//cx = self.offsetLeft;
				//x = even.offsetX - $pop[0].offsetLeft;
				//W = $("body").outerWidth();
				//left = W - $pop.width();
				//overW = cx > left ? cx-left +50 : 0;
				//$pop.css({
				//	'left':x-overW +'px'
				//});
				//

			},
			/**
			 * 汇流箱chart弹出层
			 */
			'get_pop_powerOut':function(){
				return System.Html.tag('div',false,{"class":"container MT20 center-block W100"},
							System.Html.tag('div',false,{"class":"row"},
								System.Html.tag('div',false,{"class":"col-md-12"},
									System.Html.tag('div',false,{"id":"echarts-column-chart"})

								)

							)
				);
			},
			/**
			 * 汇流箱表弹出层
			 */
			'get_pop_boxOut':function(D){
				return System.Html.tag('div',false,{"class":"container MT20 center-block W100"},
							System.Html.tag('div',false,{"class":"row"},
								System.Html.tag('div',false,{"class":"col-md-12"},
									System.Html.tag('div',false,{"class":"panel-body"},
										System.Html.tag('table',false,{"class":"table table-bordered table-hover table-striped display text-center"},
											[
												System.Html.tag('tr',false,{"class":"t-bg-blue"},
													[
														System.Html.tag('td',false,{"rowspan":"2"},'汇流箱'),
														System.Html.tag('td',false,{"rowspan":"2"},'离散率(%)'),
														System.Html.tag('td',false,{"rowspan":"2"},'总电流(A)'),
														System.Html.tag('td',false,{"colspan":"16"},'电流(A)')
													]

												),
												System.Html.tag('tr',false,{"class":"t-bg-blue"},
													System.main(function(){
														var tds=[];
														for(var i=1;i<=16;i++){
															tds.push(System.Html.tag('td',false,{},'I'+i));

														}
														return tds.join('');

													})

												),
												System.Html.tag('tr',false,{"class":""},
													System.main(function(){
														var tds=[];
														for(var i=1;i<=19;i++){
															if(1 === i){
																tds.push(System.Html.tag('td',false,{},'汇流箱0'+i));
															}else{
																tds.push(System.Html.tag('td',false,{},i));
															}


														}
														return tds.join('');

													})

												)


											]

										)
									)
								)

							)
						);

			}

		},

		'getInverterData':function(init){
			defaults={
				'$view':$('#electricalBox'),
				'isAjax':true,
				'type': 'post',
				'url':  'js/dataJson-data.json',
				'data': {},
				'init_fun':function(v,D){
					return System.Html.tag('li', false, {"class":"_zh_station col-sm-6 col-md-3", "id":"s_"+ v._id},
						[
							System.Html.tag('div', false, {"class":"_zh_station-top MB5"},
								[
									System.Html.tag('i', false, {"class":"_zh_station-stationicon mouse-hand"}),
									System.Html.tag('div', false, {"class":"_zh_station-title ML50"},
										[
											System.Html.tag('div', false, {"class":"mouse-hand"},'1#逆变器02'),
											System.Html.tag('div', false, {},'方阵名称'),
											System.Html.tag('div', false, {"class":"p-rel PL15"},
												[
													System.Html.tag('i', false, {"class":"_zh_circleImg _zh_circleImg-red"}),
													System.Html.tag('span', false, {},'中断')
												]
											)


										]
									)

								]

							),
							System.Html.tag('div', false, {"class":"_zh_station-c clearfix MB5"},
								[
									System.Html.tag('div', false, {"class":"text1"},
										[
											System.Html.tag('p', false, {},'输出功率'),
											System.Html.tag('p', false, {},'输入功率'),
											System.Html.tag('p', false, {},'单瓦发电量'),
											System.Html.tag('p', false, {},'日发电量')
										]

									),
									System.Html.tag('div', false, {"class":"data-value"},
										[
											System.Html.tag('p', false, {},v.DCP +'kW'),
											System.Html.tag('p', false, {},'88.88kW'),
											System.Html.tag('p', false, {},'42Wh'),
											System.Html.tag('p', false, {},v.daytotal +'kWh')
										]

									)

								]

							),
							System.Html.tag('div', false, {"class":"_zh_station-lineicon mouse-hand"},
								(function(){
									var tpl=[];
									for(var i=0;i<Math.round(Math.random()*30);i++){
										tpl.push(System.Html.tag('img',true,{"src":ROOT+"/css/img/greenline.png","alt":""}));
									}
									return tpl.join('');

								})()
							)
						]

					);


				},
				'getCurTpl':function(D){
					var tpl, i,len= D.data.length, v;

					for(i=0;i<len;i++){
						tpl=[];
						v= D.data[i];
						if(!System.empty( v['_id'])){
							tpl.push('<p>222</p>');
							tpl.push('<p>88.88kW</p>');
							tpl.push('<p>42Wh</p>');
							tpl.push('<p>42WhkWh</p>');

						}

						$('#s_'+v['_id']+' .data-value').html(tpl.join(''));

					}

				},
				'initTpl':function(D){
					var tpl=[], i,len= D.data.length, v;

					for(i=0;i<len;i++){
						v=D.data[i];
						if(!System.empty( v['id'])){
							if(System.isFunction(init.init_fun)){
								tpl.push(init.init_fun(v,D));

							}

						}
					}

					return tpl.join('');
				}
			};

			init = System.isObject(init) ? System.merge({},[init,defaults]) : defaults;

			var getTpl  = init.getCurTpl;
            var initTpl = init.initTpl;


			if(init.isAjax){
				System.Html.getFile(init.url || [__root__,'/js/dataJson-data.json'].join(''),function(D){
					if(init_tpl){//模版已初始化，刷新局部的某一部分
						getTpl(D);
					}else{//初始化模版，或重新刷新模版
						init_tpl =true;
						init.$view.html(initTpl(D));
					}
				},
				{
					type: init.type || 'post',
					data: init.data || {},
					dataType: 'json'

				});
				//$.ajax({
				//	type: init.type || 'post',
				//	url:  init.url  || 'js/dataJson-data.json',
				//	data: init.data || {},
				//	dataType: 'json',
				//	error:function(){
				//		throw new Error("Warning :没有取到数据！！！");
				//	},
				//	success: function(D){
				//		if(init_tpl){//模版已初始化，刷新局部的某一部分
				//			getTpl(D);
				//		}else{//初始化模版，或重新刷新模版
				//			init_tpl =true;
				//			init.$view.html(initTpl(D.data));
				//		}
                //
                //
				//	}
				//});
			}else{
				init_tpl =true;
				init.$view.html(initTpl(init.data.data));
			}



		}


	};

	I.ElectricalBox.init_tpl=function(b){
		init_tpl=b;
	};


	System.modules.exports.I=I;


});









