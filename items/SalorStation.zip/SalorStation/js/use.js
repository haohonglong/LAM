LAMJS.main([window],function(window){
	'use strict';
	var System=this;
	var I=System.modules.exports.I || {};
	I.home={

		/**
		 * 翻转效果
		 */
		'flip':function(){
			// Initialize card flip
			$('.card.hover').hover(function(){
				$(this).addClass('flip');
			},function(){
				$(this).removeClass('flip');
			});

			// Make card front & back side same

			$('.card').each(function() {
				var front = $('.card .front');
				var back = $('.card .back');
				var frontH = front.height();
				var backH = back.height();



				if (backH > frontH) {
					front.height(backH - 8);
				}
			});

			//generate pie charts
			$('.easypiechart').easyPieChart();

			//animate numbers on cards
			$("#users-count").animateNumbers(Math.round( Math.random() * 1000 ));

			//update instance every 5 sec
			window.setInterval(function() {

				//animate numbers on cards
				$( '#users-count' ).animateNumbers( Math.round( Math.random() * 1000 ) );
				$( '#orders-count' ).animateNumbers( Math.round( Math.random() * 100 ) );
				$( '#sales-count' ).animateNumbers( Math.round( Math.random() * 10000 ) );
				$( '#visits-count' ).animateNumbers( Math.round( Math.random() * 10000 ) );

				//refresh every pie chart
				$('.easypiechart').each(function() {
					$(this).data('easyPieChart').update(Math.floor(100*Math.random()));
				});

			}, 5000);
		},
		/**
		 * 累计上网电量
		 */
		'odometer':function(n){
			var count = n && parseInt(n) || 0;
			var begin,len,total,zero=[],count_s,limit=8;
			if(count > 100000000){
				begin=100000000;
			}
			if(count > 100000){
				begin=100000;
			}

			else if(count > 1000){
				begin=1000;
			}
			else if(count > 100){
				begin=100;
			}
			else if(count > 10){
				begin=10;
			}
			else{
				begin=0;
			}
			count_s = String(count);
			len =count_s.length;

			if(len < limit){

				total=limit-len;
				for(var i=0;i<total;i++){
					zero.push('0');

				}
				count_s=zero.join('')+count_s;

			}
			else if(len > limit){

			}

			$('.odometer').each(function(){
				$(this).parent().hide();
				var clock = $(this).FlipClock({
					clockFace: 'CounterFlip'
				});
				System.wait(function(){
					clock.setCounter(count_s);
				},0.5);



				$(this).parent().show();
			});



		},
		/**
		 * @author: lhh
		 * 产品介绍：
		 * 创建日期：2015-8-26
		 * 修改日期：2015-8-26
		 * 名称： rain
		 * 功能：天气控件
		 * 说明：
		 * 注意：下面俩个参数是必须的标
		 * @param 	(String)dom             NO NULL : 元素ID
		 * @return (void)
		 * Example：
		 *
		 */
		'rain':function(dom){
			var icons = new Skycons();
			icons.set(dom, Skycons.RAIN);
			icons.play();
		},

		'highcharts':function($dom){
			$dom.highcharts({
				credits: {
					enabled: false
				},
				chart: {
					zoomType: 'xy',
					marginBottom: 60,
					marginTop: 60
				},
				title: {
					text: '今日上网电量实时曲线',
					verticalAlign: 'bottom',
					floating:true,
					y:0,
					style:{
						fontSize: 18,
						fontWeight: 'bolder',
						color: '#495b79'
					}
				},
				subtitle: {
					text: ''
				},
				xAxis: [{
					categories: ['0:00', '2:00', '3:00', '4:00', '5:00', '6:00',
						'7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
					crosshair: true
				}],
				yAxis: [{ // Primary yAxis
					labels: {
						format: '{value}',
						style: {
							color: '#464646'
						}
					}

				}, { // Secondary yAxis
					title: {
						text: '发电量',
						align:'low',
						style: {
							color: '#464646'
						}
					},
					labels: {
						format: '{value}',
						style: {
							color: '#464646'
						}
					},
					opposite: true
				}],
				tooltip: {
					shared: true
				},
				legend: {
					layout: 'horizontal',
					align: 'center',
					x: 120,
					verticalAlign: 'top',
					y: 0,
					floating: true,
					backgroundColor: (Highcharts && Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'

				},
				series: [{
					name: '发电量',
					type: 'column',
					yAxis: 1,
					data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4],
					tooltip: {
						valueSuffix: ''
					},
					color: '#78b03b'

				}, {
					name: '光照辐射量',
					type: 'spline',
					data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6],
					tooltip: {
						valueSuffix: ''
					},
					color: '#f79218'
				}]
			});
		},

		'highstock':function($dom,D){
            Highcharts.setOptions({
                //设置语言为中文
                lang: {
                    loading: "Loading...",
                    months: "1月,2月,3月,4月,5月,6月,7月,8月,9月,10月,11月,12月".split(","),
                    shortMonths: "1月,2月,3月,4月,5月,6月,7月,8月,9月,10月,11月,12月".split(","),
                    weekdays: "周日,周一,周二,周三,周四,周五,周六".split(","),
                    decimalPoint: ".",
                    numericSymbols: "k,M,G,T,P,E".split(","),
                    resetZoom: "Reset zoom",
                    resetZoomTitle: "Reset zoom level 1:1",
                    thousandsSep: " "
                }
            });

            $dom.highcharts('StockChart', {
				credits: {
					enabled: false
				},

				title: {
					text: '今日上网电量实时曲线',
					verticalAlign: 'top',
					floating:true,
					y:20,
					style:{
						fontSize: 18,
						fontWeight: 'bolder',
						color: '#495b79'
					}
				},
				rangeSelector: {
					selected: 4
				},

				yAxis: {
					labels: {
						formatter: function () {
							return (this.value > 0 ? ' + ' : '') + this.value + '%';
						}
					},
					plotLines: [{
						value: 0,
						width: 2,
						color: 'silver'
					}]
				},

				plotOptions: {
					series: {
						compare: 'percent'
					}
				},

				tooltip: {
					pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.change}%)<br/>',
					valueDecimals: 2
				},

				series: D.series
			});
		},

		/**
		 * 电子时钟
		 */
		'dateTime':function(){
			var monthNames = [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ];
			var dayNames= ["星期天","星期一","星期二","星期三","星期四","星期五","星期六"];
			var newDate = new Date();
			newDate.setDate(newDate.getDate());
			$('#Date').html(newDate.getFullYear()+'年'+monthNames[newDate.getMonth()]+newDate.getDate()+'日'+' '+dayNames[newDate.getDay()]);
			setInterval( function() {
				var seconds = new Date().getSeconds();
				$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
			},1000);

			setInterval( function() {
				var minutes = new Date().getMinutes();
				$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
			},1000);

			setInterval( function() {
				var hours = new Date().getHours();
				$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
			}, 1000);
		}
	};
	/**
	 * 表格上的行为
	 */
	I.table={

		'panels':function(){
			// PANELS
			// panel close
			$('.panel-close').click(function(e){
				e.preventDefault();
				$(this).parent().parent().parent().parent().fadeOut();
			});

			$('.panel-minimize').click(function(e){
				e.preventDefault();
				var $target = $(this).parent().parent().parent().next('.panel-body');
				if($target.is(':visible')) { $('i',$(this)).removeClass('fa-chevron-up').addClass('fa-chevron-down'); }
				else { $('i',$(this)).removeClass('fa-chevron-down').addClass('fa-chevron-up'); }
				$target.slideToggle();
			});
			$('.panel-settings').click(function(e){
				e.preventDefault();
				$('#myModal').modal('show');
			});
		},
		'fitInput':function(){
			$('table input,table textarea').closest('td').addClass('P0');

		}
	};
	/**
	 * 补充bootstrap插件
	 * @type {{}}
	 */
	I.B={
		/**
		 *
		 * @author: lhh
		 * 创建日期：2016.6.21
		 * 修改日期：2016.6.21
		 * 名称：checked_dialog
		 * 功能：检测弹出层里的表单不通过时，禁止关闭弹出层
		 * 说明：
		 * 注意：
		 * @param   (Element)button       	 	NO NULL : //当前点击的按钮
		 * @param   (Boolean)istrue 	    	   NULL : //返回true 时关闭弹出框
		 * 调用方式：
		 * @return  void
		 */
		'checked_dialog':function(button,istrue){
			if(istrue){
				$(button).attr('data-dismiss','modal');
			}else{
				$(button).attr('data-dismiss','');
			}

		}

	};

	/**
	 * 开始和结束日期时间选择器
	 * @param $parent
	 */
	I.begin_end_datetimepicker=function($parent){
		$parent = $parent || $('.datetimepicker_wrapper');
		$parent.each(function(){
			var that = this;
			$(".datetimeStart",that).datetimepicker({
				format: "yyyy-mm-dd",
				autoclose: true,
				minView: "month",
				maxView: "decade",
				todayBtn: true,
				pickerPosition: "bottom-left"
			}).on("click",function(ev){
				$(".datetimeStart",that).datetimepicker("setEndDate", $(".datetimeEnd",that).val());
			}).on("hide",function(ev){
				$(".datetimeEnd",that).trigger('click');

			});
			$(".datetimeEnd",this).datetimepicker({
				format: "yyyy-mm-dd",
				autoclose: true,
				minView: "month",
				maxView: "decade",
				todayBtn: true,
				pickerPosition: "bottom-left"
			}).on("click", function (ev) {
				$(".datetimeEnd",that).datetimepicker("setStartDate", $(".datetimeStart",that).val());
			});
		});

	};



	I.scroll=function(){
		$(".scroll").css({'overflow':'hidden'}).niceScroll({cursorcolor:"#ccc"});
	};
	I.skylo=function(){
		$(document).skylo('start');
		$(document).skylo('end');
	};
	I.side=function(){
		$('ul.nav-list').accordion();

		$('li.nav-toggle > button').on('click',function(e){
			e.preventDefault();
			$('.hidden-minibar').toggleClass("hide");
			$('.site-holder').toggleClass("mini-sidebar");
			if($('.toggle-left').hasClass('fa-angle-double-left')){ $('.toggle-left').removeClass('fa-angle-double-left').addClass('fa-angle-double-right'); }
			else { $('.toggle-left').removeClass('fa-angle-double-right').addClass('fa-angle-double-left'); }


			if($('.site-holder').hasClass('mini-sidebar'))
			{
				$('.sidebar-holder').tooltip({
					selector: "a",
					container: "body",
					placement: "right"
				});
				$('li.submenu ul').tooltip('destroy');
			}
			else
			{
				$('.sidebar-holder').tooltip('destroy');
			}


		});


		$('.nav-list a').on('click',function(){
			System.wait(function(){
				I.content();
			});

			$('.nav-list li').removeClass('active');
			if('iframe' === $(this).attr('target')){
				$(this).parent().addClass('active');

			}
		});
	};
	I.powerPanel_switch=function(a,b){
		$('.switch-left').on('click',function(){
			I.home.odometer(a);
		});
		$('.switch-right').on('click',function(){
			I.home.odometer(b);
		});
	};

	I.header=function(){
		$('.btn-nav-toggle-responsive').on('click',function(){
			$('.left-sidebar').toggleClass('show-fullsidebar');
		});
	};



	I.alink=function($a){
		$(document).on('click',$a,function(){
			I.get(this);
			return false;
		});
	};
	var loading_flag=false;
	I.loading_start=function(t){
		if(!loading_flag){

			if(t){
				System.wait(function(){
					$('body').append('<div class="_lhh_loading"><i class="_lhh_loading-i"></i></div>');
				},t);
			}else{
				$('body').append('<div class="_lhh_loading"><i class="_lhh_loading-i"></i></div>');
			}
		}
		loading_flag=true;

	};
	I.loading_end=function(t){
		if(t){
			System.wait(function(){
				$('._lhh_loading').remove();
			},t);
		}else{
			$('._lhh_loading').remove();
		}


		loading_flag=false;
	};



	I.content=function(){

		var ifr=$('iframe')[0];
		if(ifr.contentDocument){
			var $menu=$('ul.nav-list');
			var f=$('#footer').height();
			var ib=$(ifr.contentDocument).find('body').height();
			$('.content_size').height(ib > $menu.height() ? ib :$menu.height());
		}
	};






	System.modules.exports.I=I;


});









