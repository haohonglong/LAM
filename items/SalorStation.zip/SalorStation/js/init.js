//加载当前项目通用文件

LAMJS.main([LAMJS.Config.Public.ROOT],function(ROOT) {
    'use strict';
    var System=this;
    System
        .import([
            "/bootstrap.min",
            "/jquery.nicescroll",
            "/use"
        ],ROOT+'/js');
        //.import(["/flipclock/flipclock"],plugins);
});